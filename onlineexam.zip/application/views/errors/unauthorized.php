

<div class="alert-danger text-center"><h1><?php echo $message; ?></h1></div>
<div class="text-center"><h3><?php echo anchor('/', 'Go Back ', ''); ?></h3></div>
