<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Error extends CI_Controller
{
	

	/**
	 * Redirect if needed, otherwise display the user list
	 */
	public function index()
	{

		

			
		
	}

	/**
	 * Log the user in
	 */
	public function unauthorized()
	{
        
    }


	
}
