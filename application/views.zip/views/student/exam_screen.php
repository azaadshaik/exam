<div id="instructions">
Please read the instructions below

<p>-> Instruction 1</p>
<p>-> Instruction 2</p>
<p>-> Instruction 3</p>
<p>-> Instruction 4</p>
<button class="signin-btn" onclick="startExam(<?php echo $exam_data->question_paper_questions[0];?>);" type="button">Start Exam</button>
</div>                 
				 
				 <!-- exams tab starts here -->
                  <div id="userSecondTab" style="display:none;">
                     <div class="stu-exam-tab col-lg12 col-md-12 col-sm-12 col-xs-12">
                        <div class="header">
                           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                              <span class="header-name"><b>Name:</b> Wasim</span>
                              <span class="header-name"><b>Exam Centre:</b> JBDC</span>
                           </div>
                           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                              <h2><?php echo $exam_data->exam_name;?></h2>
                           </div>
                           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                              <span class="header-name"><b>Timer:</b> 02:00:00</span>
                           </div>
                        </div>
                        <div class="exam-body">
						<div id="loader" class="exam-body-left col-lg-8 col-md-8 col-sm-8 col-xs-8"></div>
                           <div class="exam-body-left col-lg-8 col-md-8 col-sm-8 col-xs-8 dynamicQuestion">
                              
							  
                           </div>
						   
                           <div id="exam-ques-num" class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                              <div  class="scrollbar exam-ques-num"  id="style-1">
                                 <div class="ques-rows">
                                    <span class="btn btn-markreview">1</span>
                                    <span class="btn btn-answered">2</span>
                                    <span class="btn btn-unanswered">3</span>
                                    <span class="btn btn-current">4</span>
                                 </div>
                                 <div class="ques-rows">
                                    <span class="btn">5</span>
                                    <span class="btn">6</span>
                                    <span class="btn">7</span>
                                    <span class="btn">8</span>
                                 </div>
                                 

                                 <div class="force-overflow"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>